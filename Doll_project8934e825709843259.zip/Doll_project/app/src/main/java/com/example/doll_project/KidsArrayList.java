package com.example.doll_project;

import java.util.ArrayList;
public class KidsArrayList {
    private static ArrayList<kidsData> kidsData;

    public static ArrayList<kidsData> getKidsData()
    {

        ArrayList<kidsData> kidsDataArrayList
                = new ArrayList<>();
        kidsData kd1 = new kidsData("Chinmaya Mohapatra",
                "good");
        kidsDataArrayList.add(kd1);
        kidsData kd2
                = new kidsData("Ram prakash", "bad");
        kidsDataArrayList.add(kd2);
        kidsData kd3 = new kidsData("OMM Meheta",
                "fine");
        kidsDataArrayList.add(kd3);
        kidsData kd4 = new kidsData("Hari Mohapatra",
                "good");
        kidsDataArrayList.add(kd4);
        kidsData kd5 = new kidsData(
                "Abhisek Mishra", "Really good");
        kidsDataArrayList.add(kd5);
        kidsData kd6 = new kidsData("Sindhu Malhotra",
                "Really bad");
        kidsDataArrayList.add(kd6);
        kidsData kd7 = new kidsData("Anil sidhu",
                "okay");
        kidsDataArrayList.add(kd7);
        kidsData kd8 = new kidsData("Sachin sinha",
                "okay");
        kidsDataArrayList.add(kd8);
        kidsData kd9 = new kidsData("Amit sahoo",
                "good");
        kidsDataArrayList.add(kd9);
        kidsData kd10 = new kidsData("Raj kumar",
                "bad");
        kidsDataArrayList.add(kd10);

        return kidsDataArrayList;
    }


}
