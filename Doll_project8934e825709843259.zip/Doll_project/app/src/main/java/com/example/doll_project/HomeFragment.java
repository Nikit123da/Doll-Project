package com.example.doll_project;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HomeFragment extends Fragment implements RecyclerViewInterface {
    private String param1;
    private String param2;


    ArrayList<User> userArrayList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            param1 = getArguments().getString("param1");
            param2 = getArguments().getString("param2");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home,
                container, false);
    }

    public static HomeFragment newInstance(String param1,
                                           String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString("param1", param1);
        args.putString("param2", param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(View view,
                              Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // getting the kidsList
        ArrayList<kidsData> kidsDataArrayList
                = KidsArrayList.getKidsData();

        RecyclerViewInterface recyclerViewInterface = null;

        // Assign kidsList to ItemAdapter
        Adapter itemAdapter = new Adapter(kidsDataArrayList, getContext(), this);

        // Set the LayoutManager that
        // this RecyclerView will use.
        RecyclerView recyclerView
                = view.findViewById(R.id.recycleview);
        recyclerView.setAdapter(itemAdapter);
        recyclerView.setLayoutManager(
                new LinearLayoutManager(getContext()));

        // adapter instance is set to the
        // recyclerview to inflate the items.

    }

    @Override
    public void onClickListener(int position) {
    }

    @Override
    public void onItemClick(int position) {

    }
}

