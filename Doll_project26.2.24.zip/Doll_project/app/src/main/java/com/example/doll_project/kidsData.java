package com.example.doll_project;

import java.io.Serializable;
public class kidsData implements Serializable{
    private final String name;
    private final String feels;


    public kidsData(String name, String feels) {
        this.name = name;
        this.feels = feels;
    }

    public String getFeels() {
        return feels;
    }

    public String getName() {
        return name;
    }
}
