package com.example.doll_project;

import java.io.Serializable;

public class User implements Serializable {
    private String UserName;
    private String Email;
    private String phoneNumber;

    private int img;


    public User(String name, String Email, String phoneNumber) {

        this.UserName = name;
        this.Email=Email;
        this.phoneNumber=phoneNumber;

    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public User(String UserName, int Id){
        this.UserName=UserName;
        this.Email=Email;
    }

    public String GetUserName(){
        return this.UserName;
    }

    public String GetUserEmail(){
        return this.Email;
    }

    public void SetUserName(String NewUserName){
        this.UserName=NewUserName;
    }


    @Override
    public String toString() {
        return "User{" +
                "UserName='" + UserName + '\'' +
                ", Email='" + Email + '\'' +
                ", phoneNumber='" + phoneNumber + '\''  +
                '}';
    }
}
