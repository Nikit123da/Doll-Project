package com.example.doll_project;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
public class HomeScreen extends AppCompatActivity implements BottomNavigationView.OnItemSelectedListener, RecyclerViewInterface {

        BottomNavigationView bottomNavigationView;
        MenuItem item;

        RecyclerViewInterface recyclerViewInterface;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_home_screen);


            bottomNavigationView = findViewById(R.id.bottomNavigationView);

            bottomNavigationView.setOnItemSelectedListener(this);
            bottomNavigationView.setSelectedItemId(R.id.home);

            Adapter adapter = new Adapter(KidsArrayList.getKidsData(), this,recyclerViewInterface);


        //      RecyclerView recycle = findViewById(R.id.recycleview);
        //       recycle.setAdapter(adapter);
            BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);
        //    recycle.setLayoutManager(new LinearLayoutManager((this)));

        }

        final HomeFragment homeFragment = new HomeFragment();
        final UserFragment userFragment = new UserFragment();
        final HeartMonitorFragment heartMonitorFragment = new HeartMonitorFragment();
        final CameraFragment cameraFragment = new CameraFragment();





        @Override
        public void onPointerCaptureChanged(boolean hasCapture) {
            super.onPointerCaptureChanged(hasCapture);
        }

        @SuppressLint("NonConstantResourceId")
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {



            if (item.getItemId()==R.id.home){
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frameLayout, homeFragment)
                        .commit();
                return true;
            }

            if (item.getItemId()==R.id.heartMonitor){
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frameLayout, heartMonitorFragment)
                        .commit();
                return true;
            }

            if (item.getItemId()==R.id.camera){
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frameLayout, cameraFragment)
                        .commit();
                return true;
            }
            if (item.getItemId()==R.id.profile){
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frameLayout, userFragment)
                        .commit();
                return true;
            }
            return false;

        }

    @Override
    public void onClickListener(int position) {

    }

    @Override
    public void onItemClick(int position) {

    }
}

