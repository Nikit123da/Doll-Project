package com.example.doll_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity
        implements BottomNavigationView
        .OnNavigationItemSelectedListener
{

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }

    public class HomeScreen extends AppCompatActivity implements BottomNavigationView.OnItemSelectedListener {

        BottomNavigationView bottomNavigationView;
        MenuItem item;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_home_screen);


            bottomNavigationView = findViewById(R.id.bottomNavigationView);

            bottomNavigationView.setOnItemSelectedListener(this);
            bottomNavigationView.setSelectedItemId(R.id.profile);


            //RecyclerView recycle = findViewById(R.id.ReacicleView);
            BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

            //recycle.setLayoutManager(new LinearLayoutManager((this)));

        }

        final HomeFragment homeFragment = new HomeFragment();
        final UserFragment userFragment = new UserFragment();




        @Override
        public void onPointerCaptureChanged(boolean hasCapture) {
            super.onPointerCaptureChanged(hasCapture);
        }

        @SuppressLint("NonConstantResourceId")
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.profile:
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.frameLayout, homeFragment)
                            .commit();//SUICIDE
                    return true;

                case R.id.home:
                    getSupportFragmentManager()
                            .beginTransaction()
                            .replace(R.id.frameLayout, userFragment)
                            .commit();
                    return true;

            }

            return false;

        }
    }
}
