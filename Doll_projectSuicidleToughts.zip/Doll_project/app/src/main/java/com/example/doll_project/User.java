package com.example.doll_project;

public class User {
    private String UserName;
    private String Email;

    private int img;

    public User(String nikita, String s, int simple_logo) {

    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public User(String UserName, int Id){
        this.UserName=UserName;
        this.Email=Email;
    }

    public String GetUserName(){
        return this.UserName;
    }

    public String GetUserEmail(){
        return this.Email;
    }

    public void SetUserName(String NewUserName){
        this.UserName=NewUserName;
    }



}
