package com.example.doll_project;

public class KidsDataGrafhPoints {

    private int[][] kidsPoints;

    public KidsDataGrafhPoints(int[][] kidsPoints)
    {
        kidsPoints = this.kidsPoints;
    }

}
