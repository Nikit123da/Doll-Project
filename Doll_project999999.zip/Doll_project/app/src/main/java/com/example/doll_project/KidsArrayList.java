package com.example.doll_project;

import java.util.ArrayList;
public class KidsArrayList {
    private static ArrayList<kidsData> kidsData;

    public static ArrayList<kidsData> getKidsData()
    {

        ArrayList<kidsData> kidsDataArrayList = new ArrayList<>();

        kidsData kd1 = new kidsData("Chinmaya Mohapatra", "good", CreateKidsPoints());
        kidsDataArrayList.add(kd1);

        kidsData kd2 = new kidsData("Ram p.rakash", "bad", CreateKidsPoints());
        kidsDataArrayList.add(kd2);

        kidsData kd3 = new kidsData("OMM Meheta", "fine", CreateKidsPoints());
        kidsDataArrayList.add(kd3);

        kidsData kd4 = new kidsData("Hari Mohapatra", "good", CreateKidsPoints());
        kidsDataArrayList.add(kd4);

        kidsData kd5 = new kidsData("Abhisek Mishra", "Really good", CreateKidsPoints());
        kidsDataArrayList.add(kd5);

        kidsData kd6 = new kidsData("Sindhu Malhotra", "Really bad", CreateKidsPoints());
        kidsDataArrayList.add(kd6);

        kidsData kd7 = new kidsData("Anil sidhu", "okay", CreateKidsPoints());
        kidsDataArrayList.add(kd7);

        kidsData kd8 = new kidsData("Sachin sinha", "okay", CreateKidsPoints());
        kidsDataArrayList.add(kd8);

        kidsData kd9 = new kidsData("Amit sahoo", "good", CreateKidsPoints());
        kidsDataArrayList.add(kd9);

        kidsData kd10 = new kidsData("Raj kumar", "bad", CreateKidsPoints());
        kidsDataArrayList.add(kd10);

        return kidsDataArrayList;
    }

    public static int[][] CreateKidsPoints() {
        int row = 10;
        int colomn = 2;
        int value = 0;
        int range = 10;

        int[][] kidsPoints = new int[colomn][row];
        int i = 0;
        int j = 0;
        for (i = 0; i < colomn; i++) {
            for (j = 0; j < row; j++) {

                if (i == 0) {
                    kidsPoints[i][j] = j;
                } else {

                    kidsPoints[i][j] = value;
                    value = (int) (Math.random() * range);
                }
            }

        }


        return kidsPoints;
    }

    public static int getKidsPointX(int[][] kidsPoints, int x, int y) {
        return kidsPoints[x][y];
    }
}
