package com.example.doll_project;

public interface RecyclerViewInterface {
     void onClickListener(int position);

     void onItemClick(int position);


}
