package com.example.doll_project;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.DataPointInterface;
import com.jjoe64.graphview.series.LineGraphSeries;
import com.jjoe64.graphview.series.OnDataPointTapListener;
import com.jjoe64.graphview.series.Series;

public class RecyclviewExpention extends AppCompatActivity {

    LineGraphSeries<DataPoint> series;

   public String name,emotion;

    TextView tvName,tvEmotion;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycle_view);
     /*    double x,y;
         x = 0;
         y= 0;
        GraphView graph = findViewById(R.id.graph);
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(new DataPoint[] {
                new DataPoint(0, 1),
                new DataPoint(1, 5),
                new DataPoint(2, 3),
                new DataPoint(3, 7),
                new DataPoint(4, 6),
                new DataPoint(5, 4),
                new DataPoint(6, 0)
        });
        graph.addSeries(series);*/
        //Toast.makeText(RecyclviewExpention.this, "Series1: On Data Point clicked: "+ dataPoint, Toast.LENGTH_SHORT).show();

    Toast.makeText(RecyclviewExpention.this,"array"+KidsArrayList.CreateKidsPoints()[1][1],Toast.LENGTH_SHORT).show();

        GraphView graph = findViewById(R.id.graph);
       DataPoint[] d= new DataPoint[10];

                  for(int i = 0; i < 10; i++){
                     // d[i]=new DataPoint(0,6);
                   d[i] =  new DataPoint(KidsArrayList.CreateKidsPoints()[0][i],KidsArrayList.CreateKidsPoints()[1][i]);
                  }

        LineGraphSeries<DataPoint> series = new LineGraphSeries<>(d);

        graph.addSeries(series);

        series.setOnDataPointTapListener(new OnDataPointTapListener() {
            @Override
            public void onTap(Series series, DataPointInterface dataPoint) {
            }
        });
        GridLabelRenderer gridLabel = graph.getGridLabelRenderer();
        gridLabel.setHorizontalAxisTitle("Time");
        gridLabel.setHorizontalAxisTitleTextSize(50);
        gridLabel.setVerticalAxisTitle("Feel");
        gridLabel.setVerticalAxisTitleTextSize(50);

        tvEmotion = findViewById(R.id.tvEmotion);
        tvName = findViewById(R.id.tvName);

        Intent intent = getIntent();

        name = intent.getStringExtra("name");
        emotion = intent.getStringExtra("Emotion");

        Toast.makeText(RecyclviewExpention.this, "Name: "+ name , Toast.LENGTH_LONG).show();


        tvName.setText(name);
        tvEmotion.setText(emotion);

    }


}

